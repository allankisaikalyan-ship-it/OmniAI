package com.example.ui

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ChatMessage
import com.example.data.ChatSession
import com.example.data.UserProfile
import kotlinx.coroutines.launch

// Natural Tones styling scheme
private val ChatDarkBg = Color(0xFFFBFDF7)          // Standard background (#FBFDF7)
private val ChatMessageBg = Color(0xFFF1F1EA)       // Assistant bubble/cards bg (#F1F1EA)
private val ChatInputBg = Color(0xFFF1F1EA)         // Message input bar background (#F1F1EA)
private val ChatAccentTeal = Color(0xFF4F6354)      // User bubble / Active deep sage (#4F6354)
private val ChatSecondaryAccent = Color(0xFFDCE5DB) // Soft Sage highlight / selection (#DCE5DB)
private val CodeHeaderBg = Color(0xFFDCE5DB)        // Markdown code block title bg (#DCE5DB)
private val CodeContentBg = Color(0xFFF1F1EA)       // Light code content background (#F1F1EA)
private val TextWhite = Color(0xFF191C19)           // Standard dark text (#191C19)
private val TextMuted = Color(0xFF737973)           // Soft muted dark sage description text (#737973)

sealed interface ChatSegment {
    data class Text(val content: String) : ChatSegment
    data class Code(val language: String, val code: String) : ChatSegment
}

/**
 * Splits plain text response by triple backticks highlighting markdown code blocks.
 */
fun parseChatResponse(text: String): List<ChatSegment> {
    if (!text.contains("```")) {
        return listOf(ChatSegment.Text(text))
    }
    val segments = mutableListOf<ChatSegment>()
    val parts = text.split("```")
    for (i in parts.indices) {
        val part = parts[i]
        if (i % 2 == 1) {
            val lines = part.split("\n")
            val language = if (lines.isNotEmpty() && lines.first().trim().isNotEmpty() && lines.first().trim().length < 15) {
                lines.first().trim().uppercase()
            } else {
                "CODE"
            }
            val codeContent = if (lines.size > 1) {
                lines.drop(1).joinToString("\n")
            } else {
                part
            }
            if (codeContent.trim().isNotEmpty()) {
                segments.add(ChatSegment.Code(language, codeContent.trim()))
            }
        } else {
            if (part.isNotEmpty()) {
                segments.add(ChatSegment.Text(part))
            }
        }
    }
    return segments
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SidebarContent(
    viewModel: ChatViewModel,
    sessions: List<ChatSession>,
    currentSessionId: Long?,
    loggedInUser: UserProfile?,
    onSessionSelected: (Long) -> Unit,
    onNewChatClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(14.dp)
    ) {
        // Header Area
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(ChatAccentTeal, ChatSecondaryAccent)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Ω",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = "OmniAI Workspace",
                color = TextWhite,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold
            )
        }

        HorizontalDivider(
            color = Color.Gray.copy(alpha = 0.15f),
            modifier = Modifier.padding(vertical = 4.dp)
        )

        // Integrated Account Profile Card!
        ProfileSyncSection(
            user = loggedInUser,
            viewModel = viewModel
        )

        HorizontalDivider(
            color = Color.Gray.copy(alpha = 0.15f),
            modifier = Modifier.padding(vertical = 6.dp)
        )

        // Customizable Persona Settings (Show only if logged in)
        if (loggedInUser != null) {
            PersonaConfigSection(
                currentPersona = loggedInUser.preferredPersona,
                onPersonaChanged = { viewModel.changePersona(it) }
            )
            HorizontalDivider(
                color = Color.Gray.copy(alpha = 0.15f),
                modifier = Modifier.padding(vertical = 6.dp)
            )
        }

        // Conversation History Title Label
        Text(
            text = "CONVERSATION HISTORY",
            color = ChatAccentTeal,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(vertical = 4.dp, horizontal = 2.dp)
        )

        // New Chat Action
        OutlinedButton(
            onClick = { onNewChatClick() },
            colors = ButtonDefaults.outlinedButtonColors(contentColor = ChatAccentTeal),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp)
                .testTag("drawer_new_chat_button")
        ) {
            Icon(imageVector = Icons.Default.Add, contentDescription = "Add Icon", modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = "New Chat", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        }

        // Historic Chats list
        if (sessions.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No past chats yet",
                    color = TextMuted,
                    fontSize = 13.sp
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                items(sessions, key = { it.id }) { session ->
                    val isSelected = session.id == currentSessionId
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (isSelected) ChatSecondaryAccent
                                else Color.Transparent
                            )
                            .clickable { onSessionSelected(session.id) }
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Face,
                            contentDescription = "Chat Session",
                            tint = if (isSelected) ChatAccentTeal else TextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = session.title,
                            color = if (isSelected) TextWhite else TextMuted,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { viewModel.deleteSession(session) },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete Session",
                                tint = Color.Red.copy(alpha = 0.6f),
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        }

        // Drawer footer with simple info
        HorizontalDivider(
            color = Color.Gray.copy(alpha = 0.2f),
            modifier = Modifier.padding(vertical = 4.dp)
        )
        Text(
            text = "OmniAI v1.2.0 • Adaptive Learning Enabled",
            color = TextMuted.copy(alpha = 0.6f),
            fontSize = 10.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatMainScaffold(
    titleText: String,
    loggedInUser: UserProfile?,
    messages: List<ChatMessage>,
    generatingState: GeneratingState,
    inputText: String,
    lazyListState: androidx.compose.foundation.lazy.LazyListState,
    viewModel: ChatViewModel,
    isDesktop: Boolean,
    onMenuClick: () -> Unit
) {
    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ChatDarkBg)
                    .statusBarsPadding()
                    .height(56.dp)
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!isDesktop) {
                    IconButton(
                        onClick = onMenuClick,
                        modifier = Modifier.testTag("menu_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "Menu icon",
                            tint = ChatAccentTeal
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                } else {
                    Spacer(modifier = Modifier.width(16.dp))
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = titleText,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        color = TextWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Text(
                        text = if (loggedInUser != null) "OmniAI for ${loggedInUser.displayName} (${loggedInUser.preferredPersona})" else "OmniAI • Guest Profile",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
                IconButton(
                    onClick = { viewModel.startNewChat() },
                    modifier = Modifier.testTag("add_chat_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "New Chat Logo",
                        tint = ChatAccentTeal
                    )
                }
            }
        },
        containerColor = ChatDarkBg,
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(ChatDarkBg)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxSize()
            ) {
                // Wrapper to limit maximum width on desktop and keep layout clean/centered
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .widthIn(max = 840.dp)
                ) {
                    // Chat content list OR Dashboard Empty State
                    if (messages.isEmpty()) {
                        DashboardEmptyState(
                            onTemplateClick = { query ->
                                viewModel.setInputText(query)
                                viewModel.sendMessage()
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        LazyColumn(
                            state = lazyListState,
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(messages, key = { it.id }) { message ->
                                ChatMessageBubble(
                                    message = message,
                                    onRateMessage = { msgId, feedback, correction ->
                                        viewModel.rateResponse(msgId, feedback, correction)
                                    }
                                )
                            }
                        }
                    }
                }

                // Interactive Generation errors
                if (generatingState is GeneratingState.Error) {
                    Surface(
                        color = Color(0xFFFDE8E8),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .widthIn(max = 840.dp)
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                            .border(1.dp, Color(0xFFF8B4B4), RoundedCornerShape(12.dp))
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "Warning Logo",
                                tint = Color(0xFF9B1C1C),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = (generatingState as GeneratingState.Error).message,
                                color = Color(0xFF9B1C1C),
                                fontSize = 12.sp,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = { viewModel.dismissError() },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Close Error",
                                    tint = Color(0xFF9B1C1C),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }

                // Bottom Chat Input Bar (Centered limit for desk/tablet reading comfort)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 840.dp)
                ) {
                    ChatInputBar(
                        value = inputText,
                        onValueChange = { viewModel.setInputText(it) },
                        onSendClick = { viewModel.sendMessage() },
                        isGenerating = generatingState is GeneratingState.Generating,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    modifier: Modifier = Modifier
) {
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val sessions by viewModel.sessions.collectAsStateWithLifecycle()
    val currentSessionId by viewModel.currentSessionId.collectAsStateWithLifecycle()
    val inputText by viewModel.inputText.collectAsStateWithLifecycle()
    val generatingState by viewModel.generatingState.collectAsStateWithLifecycle()
    val loggedInUser by viewModel.loggedInUser.collectAsStateWithLifecycle()

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    val lazyListState = rememberLazyListState()

    // Determine current session title
    val currentSession = sessions.find { it.id == currentSessionId }
    val titleText = currentSession?.title ?: "New Chat"

    // Auto-scroll to bottom when messages list size changes
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            lazyListState.animateScrollToItem(messages.size - 1)
        }
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val isDesktop = maxWidth >= 720.dp

        if (isDesktop) {
            // Desktop Layout: Side-by-side Sidebar and Main Chat View (List-Detail canonical split navigation layout)
            Row(modifier = Modifier.fillMaxSize()) {
                Surface(
                    color = ChatDarkBg,
                    modifier = Modifier
                        .width(310.dp)
                        .fillMaxHeight()
                ) {
                    SidebarContent(
                        viewModel = viewModel,
                        sessions = sessions,
                        currentSessionId = currentSessionId,
                        loggedInUser = loggedInUser,
                        onSessionSelected = { sessionId ->
                            viewModel.selectSession(sessionId)
                        },
                        onNewChatClick = {
                            viewModel.startNewChat()
                        },
                        modifier = Modifier.fillMaxHeight()
                    )
                }

                VerticalDivider(
                    color = Color.Gray.copy(alpha = 0.15f),
                    modifier = Modifier.width(1.dp).fillMaxHeight()
                )

                Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    ChatMainScaffold(
                        titleText = titleText,
                        loggedInUser = loggedInUser,
                        messages = messages,
                        generatingState = generatingState,
                        inputText = inputText,
                        lazyListState = lazyListState,
                        viewModel = viewModel,
                        isDesktop = true,
                        onMenuClick = {}
                    )
                }
            }
        } else {
            // Mobile Layout: Modal Navigation Drawer styled layout with slide-out drawer list
            ModalNavigationDrawer(
                drawerState = drawerState,
                drawerContent = {
                    ModalDrawerSheet(
                        drawerContainerColor = ChatDarkBg,
                        modifier = Modifier.width(310.dp)
                    ) {
                        SidebarContent(
                            viewModel = viewModel,
                            sessions = sessions,
                            currentSessionId = currentSessionId,
                            loggedInUser = loggedInUser,
                            onSessionSelected = { sessionId ->
                                viewModel.selectSession(sessionId)
                                coroutineScope.launch { drawerState.close() }
                            },
                            onNewChatClick = {
                                viewModel.startNewChat()
                                coroutineScope.launch { drawerState.close() }
                            }
                        )
                    }
                }
            ) {
                ChatMainScaffold(
                    titleText = titleText,
                    loggedInUser = loggedInUser,
                    messages = messages,
                    generatingState = generatingState,
                    inputText = inputText,
                    lazyListState = lazyListState,
                    viewModel = viewModel,
                    isDesktop = false,
                    onMenuClick = {
                        coroutineScope.launch { drawerState.open() }
                    }
                )
            }
        }
    }
}

/**
 * Beautiful profile controller. Lets visitors sign-up/login or toggle user settings details.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileSyncSection(
    user: UserProfile?,
    viewModel: ChatViewModel
) {
    var isRegisterMode by remember { mutableStateOf(false) }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf("") }
    var statusText by remember { mutableStateOf<String?>(null) }
    var isErrorType by remember { mutableStateOf(false) }

    val context = LocalContext.current

    if (user != null) {
        // Authenticated users details view
        Card(
            colors = CardDefaults.cardColors(containerColor = ChatSecondaryAccent.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().border(1.dp, ChatSecondaryAccent, RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(ChatAccentTeal),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = user.displayName.take(1).uppercase(),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = user.displayName,
                            color = TextWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "@${user.username}",
                            color = TextMuted,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    IconButton(
                        onClick = {
                            viewModel.logout()
                            Toast.makeText(context, "Logged out", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ExitToApp,
                            contentDescription = "Log Out",
                            tint = Color.Red.copy(alpha = 0.6f),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    } else {
        // Sign-In/Register forms
        Card(
            colors = CardDefaults.cardColors(containerColor = ChatMessageBg.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().border(1.dp, ChatSecondaryAccent.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = if (isRegisterMode) "CREATE OMNI ACCOUNT" else "PROFILE LOG IN",
                    color = ChatAccentTeal,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                if (isRegisterMode) {
                    OutlinedTextField(
                        value = displayName,
                        onValueChange = { displayName = it },
                        placeholder = { Text("Display Name (e.g. John)", fontSize = 12.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ChatAccentTeal,
                            unfocusedBorderColor = ChatSecondaryAccent
                        ),
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        textStyle = LocalTextStyle.current.copy(fontSize = 13.sp)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                }

                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    placeholder = { Text("Username (lowercase)", fontSize = 12.sp) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ChatAccentTeal,
                        unfocusedBorderColor = ChatSecondaryAccent
                    ),
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    textStyle = LocalTextStyle.current.copy(fontSize = 13.sp)
                )
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    placeholder = { Text("Password", fontSize = 12.sp) },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ChatAccentTeal,
                        unfocusedBorderColor = ChatSecondaryAccent
                    ),
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    textStyle = LocalTextStyle.current.copy(fontSize = 13.sp)
                )
                
                statusText?.let {
                    Text(
                        text = it,
                        color = if (isErrorType) Color(0xFF9E1F1F) else ChatAccentTeal,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = {
                        statusText = "Authenticating..."
                        isErrorType = false
                        if (isRegisterMode) {
                            viewModel.registerUser(username, password, displayName) { success, msg ->
                                statusText = msg
                                isErrorType = !success
                                if (success) {
                                    Toast.makeText(context, "Registered profile!", Toast.LENGTH_SHORT).show()
                                    username = ""
                                    password = ""
                                    displayName = ""
                                    statusText = null
                                }
                            }
                        } else {
                            viewModel.loginUser(username, password) { success, msg ->
                                statusText = msg
                                isErrorType = !success
                                if (success) {
                                    Toast.makeText(context, "Log in successful!", Toast.LENGTH_SHORT).show()
                                    username = ""
                                    password = ""
                                    statusText = null
                                }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ChatAccentTeal),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().height(36.dp)
                ) {
                    Text(
                        text = if (isRegisterMode) "Create Profile" else "Log In Profile",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = if (isRegisterMode) "Already have an account? Sign In" else "Create account to sync history & personas ->",
                    fontSize = 10.sp,
                    color = TextMuted,
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            isRegisterMode = !isRegisterMode
                            statusText = null
                        }
                        .padding(vertical = 2.dp)
                )
            }
        }
    }
}

/**
 * Persona Config selection.
 */
@Composable
fun PersonaConfigSection(
    currentPersona: String,
    onPersonaChanged: (String) -> Unit
) {
    val personas = listOf("Friendly", "Formal", "Concise", "Detailed", "Humorous")

    Column {
        Text(
            text = "AI INTERACTION PERSONA",
            color = ChatAccentTeal,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 6.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(ChatMessageBg, RoundedCornerShape(12.dp))
                .border(1.dp, ChatSecondaryAccent, RoundedCornerShape(12.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            personas.forEach { persona ->
                val isActive = persona == currentPersona
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isActive) ChatAccentTeal else Color.Transparent)
                        .clickable { onPersonaChanged(persona) }
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = persona.take(3), // display compact 3 letters (Fre, For, Con, Det, Hum)
                        color = if (isActive) Color.White else TextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
        Text(
            text = "Persona description: style forces ${currentPersona.lowercase()} layout structure.",
            color = TextMuted,
            fontSize = 9.sp,
            modifier = Modifier.padding(top = 4.dp, start = 4.dp)
        )
    }
}

/**
 * Empty dashboard showing ChatGPT logo and 2x2 clickable prompt templates.
 */
@Composable
fun DashboardEmptyState(
    onTemplateClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val templates = listOf(
        "Explain Quantum Computing simply like I'm five.",
        "Write a clean Kotlin function to check prime numbers.",
        "Give me three unique healthy low-carb lunch ideas.",
        "Help me draft a warm thank-you email for my teammate."
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Logo spark
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(ChatAccentTeal, ChatDarkBg)
                    )
                )
                .border(2.dp, ChatAccentTeal, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Ω",
                color = Color.White,
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "OmniAI",
            color = TextWhite,
            fontWeight = FontWeight.Bold,
            fontSize = 24.sp
        )

        Text(
            text = "Adaptive Learning • Persistent Profiles",
            color = TextMuted,
            fontSize = 14.sp,
            modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
        )

        // Guide prompt grid (2x2 layout)
        Column(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            for (i in templates.indices step 2) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(ChatMessageBg)
                            .border(1.dp, Color.Gray.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                            .clickable { onTemplateClick(templates[i]) }
                            .padding(14.dp)
                    ) {
                        Text(
                            text = templates[i],
                            color = TextWhite,
                            fontSize = 13.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    if (i + 1 < templates.size) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(ChatMessageBg)
                                .border(1.dp, Color.Gray.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                                .clickable { onTemplateClick(templates[i + 1]) }
                                .padding(14.dp)
                        ) {
                            Text(
                                text = templates[i + 1],
                                color = TextWhite,
                                fontSize = 13.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Customized individual message bubble with parsed segments + code formatter.
 * Now contains custom feedback thumb buttons + teaching feedback inputs.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatMessageBubble(
    message: ChatMessage,
    onRateMessage: (Long, String, String?) -> Unit,
    modifier: Modifier = Modifier
) {
    val isUser = message.role == "user"
    val context = LocalContext.current
    var showCorrectionInput by remember { mutableStateOf(false) }
    var correctionText by remember { mutableStateOf(message.correctionFeedback ?: "") }
    var userSavedFeedback by remember { mutableStateOf(message.feedback) }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!isUser) {
            // OmniAI Spark Avatar icon
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(ChatAccentTeal),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "O",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
        }

        Column(
            modifier = Modifier.weight(1f, fill = false)
        ) {
            if (message.isPending) {
                // Shiny Pulsing loading wave for Assistant
                PulseSkeletonLoader()
            } else {
                Surface(
                    color = if (isUser) ChatAccentTeal else ChatMessageBg,
                    shape = RoundedCornerShape(
                        topStart = 24.dp,
                        topEnd = 24.dp,
                        bottomStart = if (isUser) 24.dp else 0.dp,
                        bottomEnd = if (isUser) 0.dp else 24.dp
                    ),
                    modifier = Modifier.widthIn(max = 310.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        // Parse results
                        val segments = remember(message.text) { parseChatResponse(message.text) }
                        for (segment in segments) {
                            when (segment) {
                                is ChatSegment.Text -> {
                                    Text(
                                        text = segment.content,
                                        color = if (isUser) Color.White else TextWhite,
                                        fontSize = 15.sp,
                                        lineHeight = 22.sp
                                    )
                                }
                                is ChatSegment.Code -> {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    MoshiCodeBlock(segment = segment)
                                    Spacer(modifier = Modifier.height(10.dp))
                                }
                            }
                        }
                    }
                }

                // AI Feedback system under assistant bubble
                if (!isUser) {
                    Row(
                        modifier = Modifier.padding(top = 4.dp, start = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = {
                                val next = if (userSavedFeedback == "thumbs_up") null else "thumbs_up"
                                userSavedFeedback = next
                                onRateMessage(message.id, next ?: "", null)
                            },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ThumbUp,
                                contentDescription = "Thumbs Up",
                                tint = if (userSavedFeedback == "thumbs_up") ChatAccentTeal else TextMuted.copy(alpha = 0.5f),
                                modifier = Modifier.size(13.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(
                            onClick = {
                                val next = if (userSavedFeedback == "thumbs_down") null else "thumbs_down"
                                userSavedFeedback = next
                                showCorrectionInput = (next == "thumbs_down")
                                onRateMessage(message.id, next ?: "", null)
                            },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Critique or Correct",
                                tint = if (userSavedFeedback == "thumbs_down") Color.Red.copy(alpha = 0.7f) else TextMuted,
                                modifier = Modifier.size(13.dp)
                            )
                        }

                        // Learning status tag
                        if (userSavedFeedback != null) {
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = if (userSavedFeedback == "thumbs_up") "Approved response style" else "Critiqued & under active learning",
                                color = ChatAccentTeal,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Expandable text form where you can write corrections
                    AnimatedVisibility(
                        visible = showCorrectionInput || (!message.correctionFeedback.isNullOrBlank() && userSavedFeedback == "thumbs_down"),
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically()
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(top = 6.dp, start = 4.dp, end = 2.dp)
                                .widthIn(max = 280.dp)
                                .background(ChatDarkBg, RoundedCornerShape(12.dp))
                                .border(1.dp, ChatSecondaryAccent, RoundedCornerShape(12.dp))
                                .padding(10.dp)
                        ) {
                            Text(
                                text = "Help OmniAI Learn on this topic:",
                                color = TextWhite,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                            OutlinedTextField(
                                value = correctionText,
                                onValueChange = { correctionText = it },
                                placeholder = { Text("What is the correct or missing answer?", fontSize = 11.sp) },
                                modifier = Modifier.fillMaxWidth().height(56.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = ChatAccentTeal,
                                    unfocusedBorderColor = ChatSecondaryAccent
                                ),
                                textStyle = LocalTextStyle.current.copy(fontSize = 12.sp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Button(
                                    onClick = {
                                        onRateMessage(message.id, "thumbs_down", correctionText)
                                        showCorrectionInput = false
                                        Toast.makeText(context, "Rules applied. OmniAI learned perfectly!", Toast.LENGTH_SHORT).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = ChatAccentTeal),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.height(28.dp)
                                ) {
                                    Text("Apply Rules", color = Color.White, fontSize = 10.sp)
                                }
                                TextButton(
                                    onClick = { showCorrectionInput = false },
                                    modifier = Modifier.height(28.dp)
                                ) {
                                    Text("Dismiss", color = TextMuted, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        if (isUser) {
            Spacer(modifier = Modifier.width(8.dp))
            // User letter thumbnail avatar
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(Color.Gray.copy(alpha = 0.5f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "U",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }
    }
}

/**
 * Beautiful code block component with syntax card, language header and quick Copy functionality.
 */
@Composable
fun MoshiCodeBlock(
    segment: ChatSegment.Code,
    modifier: Modifier = Modifier
) {
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .border(1.dp, Color.Gray.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
    ) {
        // Code Block Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CodeHeaderBg)
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = segment.language,
                color = TextWhite,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Row(
                modifier = Modifier
                    .clickable {
                        clipboardManager.setText(AnnotatedString(segment.code))
                        Toast.makeText(context, "Code copied!", Toast.LENGTH_SHORT).show()
                    }
                    .padding(3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Share, // standard Core icon as Copy placeholder
                    contentDescription = "Copy code",
                    tint = TextMuted,
                    modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Copy",
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // Code Content Block
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(CodeContentBg)
                .padding(12.dp)
        ) {
            Text(
                text = segment.code,
                color = TextWhite, // High contrast natural dark text
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                lineHeight = 18.sp
            )
        }
    }
}

/**
 * High quality typewriter pulsing animation to indicate thinking state.
 */
@Composable
fun PulseSkeletonLoader() {
    val transition = rememberInfiniteTransition(label = "pulse")
    val alpha by transition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )

    Row(
        modifier = Modifier
            .padding(top = 4.dp)
            .background(Color.Transparent),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(ChatAccentTeal.copy(alpha = alpha))
        )
        Spacer(modifier = Modifier.width(6.dp))
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(ChatAccentTeal.copy(alpha = (alpha + 0.3f).coerceIn(0.4f, 1f)))
        )
        Spacer(modifier = Modifier.width(6.dp))
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(ChatAccentTeal.copy(alpha = (alpha + 0.6f).coerceIn(0.4f, 1f)))
        )
    }
}

/**
 * Round pill ChatGPT input entry node.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatInputBar(
    value: String,
    onValueChange: (String) -> Unit,
    onSendClick: () -> Unit,
    isGenerating: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(ChatDarkBg)
            .padding(12.dp)
            .navigationBarsPadding() // Notch and navigation bar safe areas spacing rule
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(ChatInputBg)
                .padding(horizontal = 14.dp, vertical = 2.dp)
        ) {
            TextField(
                value = value,
                onValueChange = onValueChange,
                placeholder = {
                    Text(
                        text = "Message OmniAI...",
                        color = TextMuted,
                        fontSize = 14.sp
                    )
                },
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Sentences,
                    imeAction = ImeAction.Send
                ),
                keyboardActions = KeyboardActions(
                    onSend = { if (value.isNotBlank() && !isGenerating) onSendClick() }
                ),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    disabledContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = TextWhite,
                    unfocusedTextColor = TextWhite
                ),
                maxLines = 4,
                modifier = Modifier
                    .weight(1f)
                    .testTag("chat_input_text")
            )

            Spacer(modifier = Modifier.width(8.dp))

            // Dynamic color indicator or loading circular
            IconButton(
                onClick = onSendClick,
                enabled = value.isNotBlank() && !isGenerating,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(
                        if (value.isNotBlank() && !isGenerating) ChatAccentTeal
                        else Color.Gray.copy(alpha = 0.2f)
                    )
                    .testTag("send_button")
            ) {
                if (isGenerating) {
                    CircularProgressIndicator(
                        strokeWidth = 2.dp,
                        color = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send Message",
                        tint = if (value.isNotBlank()) Color.White else TextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "OmniAI adapts dynamically to details. Check options inside the Side Drawer.",
            color = TextMuted.copy(alpha = 0.45f),
            fontSize = 9.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
