package com.example.data

import com.example.api.GeminiApiService
import com.example.api.GeminiContent
import com.example.api.GeminiPart
import com.example.api.GeminiRequest
import com.example.api.RetrofitClient
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class ChatRepository(
    private val chatDao: ChatDao,
    private val apiService: GeminiApiService = RetrofitClient.service
) {
    // Session operations based on user owner
    fun getSessionsForUser(userId: Long?): Flow<List<ChatSession>> {
        return if (userId != null) {
            chatDao.getSessionsForUser(userId)
        } else {
            chatDao.getGuestSessions()
        }
    }

    fun getMessagesForSession(sessionId: Long): Flow<List<ChatMessage>> =
        chatDao.getMessagesForSession(sessionId)

    suspend fun createNewSession(title: String, userId: Long? = null): Long = withContext(Dispatchers.IO) {
        chatDao.insertSession(ChatSession(title = title, userId = userId))
    }

    suspend fun updateSession(session: ChatSession) = withContext(Dispatchers.IO) {
        chatDao.updateSession(session)
    }

    suspend fun deleteSession(session: ChatSession) = withContext(Dispatchers.IO) {
        chatDao.deleteSession(session)
    }

    suspend fun deleteMessageById(messageId: Long) = withContext(Dispatchers.IO) {
        chatDao.deleteMessageById(messageId)
    }

    suspend fun insertMessage(message: ChatMessage): Long = withContext(Dispatchers.IO) {
        chatDao.insertMessage(message)
    }

    // Feedback saving for adaptive learning
    suspend fun updateMessageFeedback(messageId: Long, feedback: String?, correction: String?) = withContext(Dispatchers.IO) {
        chatDao.updateMessageFeedback(messageId, feedback, correction)
    }

    // User profiles & auth operations
    suspend fun createProfile(username: String, passwordPlain: String, displayName: String): Long = withContext(Dispatchers.IO) {
        val profile = UserProfile(
            username = username,
            passwordPlain = passwordPlain,
            displayName = displayName
        )
        chatDao.insertProfile(profile)
    }

    suspend fun verifyAndLogin(username: String, passwordPlain: String): UserProfile? = withContext(Dispatchers.IO) {
        val found = chatDao.getProfileByUsername(username)
        if (found != null && found.passwordPlain == passwordPlain) {
            found
        } else {
            null
        }
    }

    suspend fun updateProfile(profile: UserProfile) = withContext(Dispatchers.IO) {
        chatDao.updateProfile(profile)
    }

    suspend fun getProfileById(id: Long): UserProfile? = withContext(Dispatchers.IO) {
        chatDao.getProfileById(id)
    }

    /**
     * Generates title from first text.
     */
    fun generateTitleFromText(text: String): String {
        val cleaned = text.trim()
        if (cleaned.isEmpty()) return "New Chat"
        val words = cleaned.split("\\s+".toRegex())
        return if (words.size <= 4) {
            cleaned
        } else {
            words.take(4).joinToString(" ") + "..."
        }
    }

    /**
     * Sends the conversation history to Gemini and inserts the response into database.
     * Incorporates:
     * - Chosen Persona settings ("Friendly", "Formal", "Concise", "Detailed", "Humorous")
     * - Display Name context (says greetings, remembers personal details)
     * - Adaptive learning inputs (appends historical positive and negative corrected comments for refining)
     */
    suspend fun generateAssistantResponse(sessionId: Long, userId: Long?): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            throw IllegalStateException("Gemini API key is not configured. Please set your API key in the AI Studio Secrets panel.")
        }

        // Get chat history up to now, filtering out any pending/placeholder messages
        val history = chatDao.getMessagesForSessionOnce(sessionId)
            .filter { !it.isPending }

        // Fetch user profile settings
        val profile = if (userId != null) chatDao.getProfileById(userId) else null
        val displayName = profile?.displayName ?: "Guest"
        val preferredPersona = profile?.preferredPersona ?: "Friendly"

        // Load historical user rating corrections for adaptive learning loop
        val historicalFeedbacks = chatDao.getAllFeedbackMessages()
        val thumbsUpSnippets = historicalFeedbacks.filter { it.feedback == "thumbs_up" }.take(5)
        val thumbsDownSnippets = historicalFeedbacks.filter { it.feedback == "thumbs_down" }.take(5)

        val adaptiveFeedbackPrompt = StringBuilder()
        if (thumbsUpSnippets.isNotEmpty() || thumbsDownSnippets.isNotEmpty()) {
            adaptiveFeedbackPrompt.append("\n\n=== RECENT USER CONVERSATIONAL PREFERENCES (ADAPTIVE LEARNING FEEDBACK) ===\n")
            adaptiveFeedbackPrompt.append("You have access to historical user interactions where they evaluated your performance. Refine your answers dynamically based on these rules:\n")
            
            if (thumbsUpSnippets.isNotEmpty()) {
                adaptiveFeedbackPrompt.append("\nUser APPROVED of these styles (Maintain or emulate this quality):\n")
                thumbsUpSnippets.forEach {
                    adaptiveFeedbackPrompt.append("- APPROVED APPROACH: \"${it.text.take(120)}\"\n")
                }
            }
            if (thumbsDownSnippets.isNotEmpty()) {
                adaptiveFeedbackPrompt.append("\nUser DISAPPROVED of these or found knowledge lacking (AVOID these mistakes):\n")
                thumbsDownSnippets.forEach {
                    adaptiveFeedbackPrompt.append("- DISLIKED WORK: \"${it.text.take(120)}\"\n")
                    if (!it.correctionFeedback.isNullOrBlank()) {
                        adaptiveFeedbackPrompt.append("  * CORRECTION INSTRUCTION GIVEN BY USER: \"${it.correctionFeedback}\"\n")
                    }
                }
            }
            adaptiveFeedbackPrompt.append("\n=========================================================================\n")
        }

        // Construct persona system instructions
        val personaInstructionMap = mapOf(
            "Friendly" to "Speak warmly, encouragingly, use conversational guides, and be highly approachable, supportive, and kind.",
            "Formal" to "Maintain a highly sophisticated professional etiquette, use impeccable academic grammar, structured syntax, and stately professional phrasing.",
            "Concise" to "Be extremely direct, brief, and highly punchy. Restrict responses to short, dense paragraphs or up to three precise bulleted sentences.",
            "Detailed" to "Provide rich, exhaustive explanations, comprehensive analysis, and thorough step-by-step breakdowns addressing all facets of inquiries.",
            "Humorous" to "Infuse dry wit, playful banter, clever remarks, or gentle self-aware humor where appropriate to make your answers thoroughly engaging while remaining deeply accurate."
        )
        val personaDetail = personaInstructionMap[preferredPersona] ?: personaInstructionMap["Friendly"]

        // Map messages to GeminiContent structure
        val contents = history.map { message ->
            val mappedRole = if (message.role == "user") "user" else "model"
            GeminiContent(
                role = mappedRole,
                parts = listOf(GeminiPart(text = message.text))
            )
        }

        // System instructions to make OmniAI feel like an all-rounder super intelligence
        val systemInstruction = GeminiContent(
            parts = listOf(
                GeminiPart(
                    text = "You are OmniAI, a helpful, highly intelligent, friendly, and omniscient AI assistant. " +
                            "You are an all-rounder who knows everything a human being knows. " +
                            "You have full access to conversation memory above and should build on past context naturally. " +
                            "Give concise, easy-to-understand, beautifully formatted replies using clean paragraphs, bullet points, list items, and markdown layout. " +
                            "Always respond with deep clarity but break down complex ideas so anyone can understand them easily. " +
                            "\n\nCURRENT LOGGED-IN USER: The user's name is \"$displayName\". " +
                            "Remember to greet \"$displayName\" warmly and reference their custom profile or name naturally when beginning or ending a sequence if appropriate." +
                            "\n\nSELECTED SYSTEM PERSONA STYLE: \"$preferredPersona\". " +
                            "You MUST adapt your vocabulary, length, pacing, and tone to target this persona rule: $personaDetail" +
                            adaptiveFeedbackPrompt.toString() +
                            "\n\nIf the user specifies corrections, or evaluates an response as thumbs down, acknowledge that you are actively learning, adapt your internal knowledge base, and politely ask learning/clarifying questions to improve your support on that topic."
                )
            )
        )

        val requestBody = GeminiRequest(
            contents = contents,
            systemInstruction = systemInstruction
        )

        val modelsToTry = listOf("gemini-3.5-flash", "gemini-2.5-flash", "gemini-flash-latest")
        var lastException: Exception? = null
        var textResult: String? = null

        for (modelName in modelsToTry) {
            try {
                val response = apiService.generateContent(
                    model = modelName,
                    apiKey = apiKey,
                    request = requestBody
                )
                val parsedText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                if (!parsedText.isNullOrBlank()) {
                    textResult = parsedText
                    break
                }
            } catch (e: Exception) {
                lastException = e
                // Continue trying other stable models in case of transient 503 or model unavailability
            }
        }

        if (textResult == null) {
            throw lastException ?: Exception("No response parsed from Gemini API Candidates under any model.")
        }

        // Insert response to local Room Database
        val assistantMsg = ChatMessage(
            sessionId = sessionId,
            role = "model",
            text = textResult
        )
        chatDao.insertMessage(assistantMsg)

        textResult
    }
}
