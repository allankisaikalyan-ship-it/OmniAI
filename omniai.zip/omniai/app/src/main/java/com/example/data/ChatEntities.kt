package com.example.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import androidx.room.Index

@Entity(
    tableName = "user_profiles",
    indices = [Index(value = ["username"], unique = true)]
)
data class UserProfile(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val username: String,
    val passwordPlain: String, // simple clean auth matching user's friendly experience goal
    val displayName: String,
    val preferredPersona: String = "Friendly" // "Friendly", "Formal", "Concise", "Detailed", "Humorous"
)

@Entity(
    tableName = "chat_sessions",
    foreignKeys = [
        ForeignKey(
            entity = UserProfile::class,
            parentColumns = ["id"],
            childColumns = ["userId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["userId"])]
)
data class ChatSession(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long? = null, // null for temporary guest sessions
    val title: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "chat_messages",
    foreignKeys = [
        ForeignKey(
            entity = ChatSession::class,
            parentColumns = ["id"],
            childColumns = ["sessionId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["sessionId"])]
)
data class ChatMessage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val role: String, // "user" or "model"
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isPending: Boolean = false,
    val feedback: String? = null, // "thumbs_up", "thumbs_down" or null
    val correctionFeedback: String? = null // custom text filled by user clarifying what AI missed or got wrong
)
