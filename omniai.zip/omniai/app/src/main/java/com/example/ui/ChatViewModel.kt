package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ChatDatabase
import com.example.data.ChatMessage
import com.example.data.ChatRepository
import com.example.data.ChatSession
import com.example.data.UserProfile
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val db = ChatDatabase.getDatabase(application)
    private val repository = ChatRepository(db.chatDao())

    // Tracks currently authenticated user profile
    private val _loggedInUser = MutableStateFlow<UserProfile?>(null)
    val loggedInUser: StateFlow<UserProfile?> = _loggedInUser.asStateFlow()

    // Dynamic sessions: filters according to authenticated user id (or Guest if null)
    val sessions: StateFlow<List<ChatSession>> = _loggedInUser
        .flatMapLatest { user ->
            repository.getSessionsForUser(user?.id)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Selected session ID
    private val _currentSessionId = MutableStateFlow<Long?>(null)
    val currentSessionId: StateFlow<Long?> = _currentSessionId.asStateFlow()

    // Text box field
    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    // Activity state
    private val _generatingState = MutableStateFlow<GeneratingState>(GeneratingState.Idle)
    val generatingState: StateFlow<GeneratingState> = _generatingState.asStateFlow()

    // Messages sequence for active session ID
    val messages: StateFlow<List<ChatMessage>> = _currentSessionId
        .flatMapLatest { sessionId ->
            if (sessionId == null) {
                flowOf(emptyList())
            } else {
                repository.getMessagesForSession(sessionId)
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    init {
        viewModelScope.launch {
            // Automatically pre-load the latest chat session when sessions lists refresh
            sessions.collect { list ->
                if (list.isNotEmpty() && _currentSessionId.value == null) {
                    _currentSessionId.value = list.first().id
                }
            }
        }
    }

    // User authentication: Register
    fun registerUser(username: String, passwordPlain: String, displayName: String, onComplete: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            try {
                val cleanUser = username.trim().lowercase()
                val cleanDisplay = displayName.trim()
                if (cleanUser.isEmpty() || passwordPlain.isEmpty() || cleanDisplay.isEmpty()) {
                    onComplete(false, "Please fill in all registration fields.")
                    return@launch
                }
                val id = repository.createProfile(cleanUser, passwordPlain, cleanDisplay)
                val profile = repository.getProfileById(id)
                if (profile != null) {
                    _loggedInUser.value = profile
                    // Automatically spawn a starting chat session for the new profile
                    val firstSessionId = repository.createNewSession("Omni AI Introduction", profile.id)
                    _currentSessionId.value = firstSessionId
                    
                    // Pre-fill introduction from Omni AI
                    repository.insertMessage(
                        ChatMessage(
                            sessionId = firstSessionId,
                            role = "model",
                            text = "Hello $cleanDisplay! Warm welcome to your personalized OmniAI workspace.\n\nI have successfully loaded your user profile. I can remember our conversations, adapt to your favorite customizable persona, and learn from your feedback. How can I help you today?"
                        )
                    )
                    _inputText.value = ""
                    onComplete(true, "Profile registered successfully!")
                } else {
                    onComplete(false, "Failed to instantiate profile.")
                }
            } catch (e: Exception) {
                onComplete(false, "Username '${username}' is already taken. Try logging in or use another username.")
            }
        }
    }

    // User authentication: Login
    fun loginUser(username: String, passwordPlain: String, onComplete: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            try {
                val cleanUser = username.trim().lowercase()
                if (cleanUser.isEmpty() || passwordPlain.isEmpty()) {
                    onComplete(false, "Please enter both username and password.")
                    return@launch
                }
                val verifiedProfile = repository.verifyAndLogin(cleanUser, passwordPlain)
                if (verifiedProfile != null) {
                    _loggedInUser.value = verifiedProfile
                    
                    // Switch to user's sessions
                    val userSessions = sessions.value
                    if (userSessions.isNotEmpty()) {
                        _currentSessionId.value = userSessions.first().id
                    } else {
                        // If no sessions, spawn a new welcome session
                        val firstSessionId = repository.createNewSession("Omni AI Welcome", verifiedProfile.id)
                        _currentSessionId.value = firstSessionId
                        repository.insertMessage(
                            ChatMessage(
                                sessionId = firstSessionId,
                                role = "model",
                                text = "Welcome back, ${verifiedProfile.displayName}! It's great to see you again.\n\nOur conversational memory has been restored, and I am applying your preferred '${verifiedProfile.preferredPersona}' persona settings."
                            )
                        )
                    }
                    _inputText.value = ""
                    onComplete(true, "Welcome back!")
                } else {
                    onComplete(false, "Invalid username or password credentials.")
                }
            } catch (e: Exception) {
                onComplete(false, e.message ?: "Authentication error occurred.")
            }
        }
    }

    // User logout
    fun logout() {
        _loggedInUser.value = null
        _currentSessionId.value = null
        _inputText.value = ""
        _generatingState.value = GeneratingState.Idle
    }

    fun setInputText(text: String) {
        _inputText.value = text
    }

    fun selectSession(sessionId: Long) {
        _currentSessionId.value = sessionId
        _generatingState.value = GeneratingState.Idle
    }

    fun startNewChat() {
        viewModelScope.launch {
            val user = _loggedInUser.value
            val defaultTitle = "New Chat"
            val newId = repository.createNewSession(defaultTitle, user?.id)
            _currentSessionId.value = newId
            _generatingState.value = GeneratingState.Idle
            _inputText.value = ""
        }
    }

    fun deleteSession(session: ChatSession) {
        viewModelScope.launch {
            repository.deleteSession(session)
            if (_currentSessionId.value == session.id) {
                val remaining = sessions.value.filter { it.id != session.id }
                if (remaining.isNotEmpty()) {
                    _currentSessionId.value = remaining.first().id
                } else {
                    _currentSessionId.value = null
                }
            }
        }
    }

    // Rate response & custom corrections (learning loop)
    fun rateResponse(messageId: Long, rating: String, correction: String? = null) {
        viewModelScope.launch {
            repository.updateMessageFeedback(messageId, rating, correction)
        }
    }

    // Customize system persona
    fun changePersona(persona: String) {
        val user = _loggedInUser.value
        if (user != null) {
            viewModelScope.launch {
                val updated = user.copy(preferredPersona = persona)
                repository.updateProfile(updated)
                _loggedInUser.value = updated
            }
        } else {
            // Guest default profile updater flow mock - create anonymous profile if requested,
            // or simply notify guest profile state
        }
    }

    fun sendMessage() {
        val query = _inputText.value.trim()
        if (query.isEmpty()) return

        val sessionId = _currentSessionId.value
        val user = _loggedInUser.value
        _inputText.value = ""

        viewModelScope.launch {
            val activeSessionId = if (sessionId == null) {
                val autoTitle = repository.generateTitleFromText(query)
                val newId = repository.createNewSession(autoTitle, user?.id)
                _currentSessionId.value = newId
                newId
            } else {
                val currentSession = sessions.value.find { it.id == sessionId }
                if (currentSession != null && currentSession.title == "New Chat") {
                    val updatedSession = currentSession.copy(
                        title = repository.generateTitleFromText(query)
                    )
                    repository.updateSession(updatedSession)
                }
                sessionId
            }

            // Insert user message
            val userMsg = ChatMessage(
                sessionId = activeSessionId,
                role = "user",
                text = query
            )
            repository.insertMessage(userMsg)

            // Transition status
            _generatingState.value = GeneratingState.Generating

            // We insert a transient pending message to trigger a neat waiting indicator
            val pendingMsgId = repository.insertMessage(
                ChatMessage(
                    sessionId = activeSessionId,
                    role = "model",
                    text = "",
                    isPending = true
                )
            )

            try {
                repository.generateAssistantResponse(activeSessionId, user?.id)
                _generatingState.value = GeneratingState.Idle
            } catch (e: Exception) {
                _generatingState.value = GeneratingState.Error(e.message ?: "An unexpected connection error occurred")
            } finally {
                repository.deleteMessageById(pendingMsgId)
            }
        }
    }

    fun dismissError() {
        if (_generatingState.value is GeneratingState.Error) {
            _generatingState.value = GeneratingState.Idle
        }
    }
}

sealed interface GeneratingState {
    object Idle : GeneratingState
    object Generating : GeneratingState
    data class Error(val message: String) : GeneratingState
}
